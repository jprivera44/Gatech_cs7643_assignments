rm -rf assignment4_submission.zip
zip -r assignment4_submission.zip models/ Machine_Translation.ipynb